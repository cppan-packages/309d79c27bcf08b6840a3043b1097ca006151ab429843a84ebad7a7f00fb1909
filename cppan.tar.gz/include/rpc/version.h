#pragma once

#ifndef VERSION_H_UMZFBKB4
#define VERSION_H_UMZFBKB4

namespace rpc {

static constexpr unsigned VERSION_MAJOR = 1;
static constexpr unsigned VERSION_MINOR = 0;
static constexpr unsigned VERSION_PATCH = 0;

} /* rpc */

#endif /* end of include guard: VERSION_H_UMZFBKB4 */
